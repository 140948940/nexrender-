const fs = require('fs')
// const {Storage} = require('@google-cloud/storage')
const OSS = require('ali-oss')
// const storage = new Storage()

/* define public methods */
const download = (job, settings, src, dest, params, type) => {
	// const parsed_src = src.replace('gs://', '').split('/')
	// const bucket_name = parsed_src[0]
	// const item = parsed_src.slice(1).join('/')
	// const file = fs.createWriteStream(dest)

	// if (!bucket_name) {
	//     return Promise.reject(new Error('GCS bucket not provided.'))
	// }
	// if (!item) {
	//     return Promise.reject(new Error('GCS item not provided.'))
	// }

	// return new Promise((resolve, reject) => {
	//     file.on('close', resolve)

	//     storage
	//         .bucket(bucket_name)
	//         .file(item)
	//         .createReadStream()
	//         .on('error', reject)
	//         .pipe(file)
	// })
}

const upload = (job, settings, src, params) => {
		console.log("job: " + JSON.stringify(job));

		console.log("settings: " + JSON.stringify(settings));
		console.log("src: " + JSON.stringify(settings));
		console.log("params: " + JSON.stringify(settings));
		// 本地路径
		var href=job.actions.postrender[job.actions.postrender.length-1].input
		console.log("href",href)
		// 阿里云相关配置
		var os=job.actions.postrender[job.actions.postrender.length-1].params
		// 文件在阿里云路径
		var filepaths=job.actions.postrender[job.actions.postrender.length-1].output
		console.log("os",JSON.stringify(os))
		const client = new OSS(os);

		async function put() {
			try {
				//object-name可以自定义为文件名（例如file.txt）或目录（例如abc/test/file.txt）的形式，实现将文件上传至当前Bucket或Bucket下的指定目录。
				let result = await client.put(filepaths, href);
				console.log("返回信息:", result);
			} catch (e) {
				console.log("错误：", e);
			}
		}

		put();
		// if (!params.bucket) {
		//     return Promise.reject(new Error('GCS bucket not provided.'))
		// }
		// if (!params.item) {
		//     return Promise.reject(new Error('GCS item not provided.'))
		// }

		// const onUploadStart = (src) => {
		//     settings.logger.log(`[${job.uid}] action-upload: upload started`)
		// }

		// const onUploadEnd = () => {
		//     settings.logger.log(`[${job.uid}] action-upload: upload complete`)
		// }

		// return new Promise((resolve, reject) => {
		//     const bucket = storage.bucket(params.bucket)
		//     const file = bucket.file(params.item)
		//     const options = {}
		//     if (params.contentType) {
		//         options.metadata = {
		//             contentType: params.contentType
		//         }
		//     }
		//     const in_stream = fs.createReadStream(src)
		//         .on('error', reject)
		//     const out_stream = file.createWriteStream(options)
		//         .on('error', reject)
		//         .on('finish', ()=> {
		//             onUploadEnd()
		//             resolve()
		//         })
		//         .on('pipe', onUploadStart)
		//     in_stream.pipe(out_stream)
		// })
	}
// 	[670 OwudyrozVJQjpsplVB] starting action - upload action
// job: {
// 	"uid": "670OwudyrozVJQjpsplVB",
// 	"type": "default",
// 	"state": "render:postrender",
// 	"output": "E:\\jieyingAE\\wenshen\\670OwudyrozVJQjpsplVB\\result.avi",
// 	"template": {
// 		"src": "file:///E:/jieyingAE/wenshen/jieying365_2.aep",
// 		"composition": "main",
// 		"dest": "E:\\jieyingAE\\wenshen\\670OwudyrozVJQjpsplVB\\jieying365_2.aep"
// 	},
// 	"assets": [{
// 		"type": "data",
// 		"layerName": "jieying365",
// 		"property": "Source Text",
// 		"value": "jieying365\n45435345"
// 	}],
// 	"actions": {
// 		"postrender": [{
// 			"module": "@nexrender/action-encode",
// 			"preset": "mp4",
// 			"output": "encoded.mp4"
// 		}, {
// 			"module": "@nexrender/action-copy",
// 			"input": "encoded.mp4",
// 			"output": "E:/jieyingAE/wenshen/myresult.mp4"
// 		}, {
// 			"module": "@nexrender/action-upload",
// 			"input": "E:/jieyingAE/wenshen/myresult.mp4",
// 			"provider": "gs",
// 			"params": {
// 				"accessKeyId": "LTAI4GCWQtzzpwyW2qkUEeYw",
// 				"accessKeySecret": "BSULD1HsyUUgGkkzRaJPXQzCmLmdCN",
// 				"bucket": "jieyingvideo",
// 				"region": "oss-cn-hangzhou.aliyuncs.com"
// 			}
// 		}]
// 	},
// 	"resultname": "result.avi",
// 	"workpath": "E:\\jieyingAE\\wenshen\\670OwudyrozVJQjpsplVB",
// 	"scriptfile": "E:\\jieyingAE\\wenshen\\670OwudyrozVJQjpsplVB\\nexrender-670OwudyrozVJQjpsplVB-script.jsx"
// }
// settings: {
// 	"workpath": "E:/jieyingAE/wenshen/",
// 	"addLicense": false,
// 	"forceCommandLinePatch": false,
// 	"skipCleanup": true,
// 	"skipRender": false,
// 	"stopOnError": false,
// 	"debug": false,
// 	"multiFrames": false,
// 	"__initialized": true,
// 	"binary": "D:\\AE\\Adobe After Effects CC 2019\\Support Files\\aerender.exe",
// 	"logger": {},
// 	"wsl": false
// }
// src: {
// 	"workpath": "E:/jieyingAE/wenshen/",
// 	"addLicense": false,
// 	"forceCommandLinePatch": false,
// 	"skipCleanup": true,
// 	"skipRender": false,
// 	"stopOnError": false,
// 	"debug": false,
// 	"multiFrames": false,
// 	"__initialized": true,
// 	"binary": "D:\\AE\\Adobe After Effects CC 2019\\Support Files\\aerender.exe",
// 	"logger": {},
// 	"wsl": false
// }
// params: {
// 		"workpath": "E:/jieyingAE/wenshen/",
// 		"addLicense": false,
// 		"forceCommandLinePatch": false,
// 		"skipCleanup": true,
// 		"skipRender": false,
// 		"stopOnError": false,
// 		"debug": false,
// 		"multiFrames": false,
// 		"__initialized": true,
// 		"binary": "D:\\AE\\Adobe After Effects CC 2019\\Support Files\\aerender.exe",
// 		"logger": {},
// 		"wsl": false
// 	} >
// 	job rendering failed
// TypeError: Cannot read property 'catch' of undefined
// at C: \Users\ liuyingfa\ AppData\ Roaming\ npm\ node_modules\ @nexrender\ cli\ node_modules\ _ @nexrender_core @1 .19 .2 @ @nexrender\ core\ src\ tasks\ actions
// 	.js: 24: 74
// at processTicksAndRejections(internal / process / task_queues.js: 93: 5)
// 错误： Error[RequestError]: getaddrinfo ENOTFOUND jieyingvideo.oss - cn - hangzhou.aliyuncs.com.aliyuncs.com, PUT http: //jieyingvideo.oss-cn-hangzhou.aliyuncs.com.aliyuncs.com/jieying/liuyingfa.mp4 -1 (connected: false, keepalive socket: false, agent status: {"createSocketCount":1,"createSocketErrorCount":0,"closeSocketCount":0,"errorSocketCount":0,"timeoutSocketCount":0,"requestCount":0,"freeSockets":{},"sockets":{"jieyingvideo.oss-cn-hangzhou.aliyuncs.com.aliyuncs.com:80:":1},"requests":{}}, socketHandledRequests: 1, socketHandledResponses: 0)
// 	headers: {}
// at Client.requestError(C: \Users\ liuyingfa\ AppData\ Roaming\ npm\ node_modules\ ali - oss\ lib\ client.js: 329: 13)
// at Client.request(C: \Users\ liuyingfa\ AppData\ Roaming\ npm\ node_modules\ ali - oss\ lib\ client.js: 182: 22)
// at processTicksAndRejections(internal / process / task_queues.js: 93: 5)
// at async Client.putStream(C: \Users\ liuyingfa\ AppData\ Roaming\ npm\ node_modules\ ali - oss\ lib\ object.js: 136: 18)
// at async Client.put(C: \Users\ liuyingfa\ AppData\ Roaming\ npm\ node_modules\ ali - oss\ lib\ object.js: 70: 12)
// at async put(C: \Users\ liuyingfa\ AppData\ Roaming\ npm\ node_modules\ @nexrender\ provider - gs\ src\ index.js: 43:
// 	19) {
// 	status: -1,
// 	code: 'RequestError'
// }
module.exports = {
	download,
	upload,
}
