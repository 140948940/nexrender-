// simple test of code syntax
require('../src')
